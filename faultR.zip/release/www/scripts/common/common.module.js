(function() {
	'use strict';

	angular
		.module('barebone.common', ['ionic']);
})();