(function() {
	'use strict';

	angular
		.module('barebone.infrastructure', []);
})();